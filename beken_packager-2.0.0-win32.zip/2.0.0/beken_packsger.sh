#!/bin/bash

echo "第一个参数: $1"
echo "第二个参数: $2"

#$1/beken_packager  $1/config.json
#cp all_2M.1220.bin $2